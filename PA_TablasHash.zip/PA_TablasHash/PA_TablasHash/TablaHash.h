#pragma once

#include "stdlib.h"
#include "Lista.h"
#include "string.h"

// Se define el n�mero de casillas predeterminado para cada tabla creada en la clase
// y la definici�n VACIO para indicar una variable NULL.
#define NCASILLAS 100
#define VACIO NULL

// Una variable char* est�tica contiene todos los elementos eliminados durante la ejecuci�n del programa.
static char * BORRADO;

typedef char **TablaHash;


/// <summary>
/// M�todo utilizado para generar la tabla hash de tama�o NCASILLAS (100).
/// </sumary>
/// <returns>
/// Devuelve la variable "t", que es una tabla Hash generarada. 
/// </returns>
TablaHash CrearTablaHash()
{
	TablaHash t;
	register int i;

	t = (TablaHash)malloc(NCASILLAS*sizeof(char *));
	if (t == NULL)
		printf("Memoria Insuficiente.");

	for (i = 0; i<NCASILLAS; i++)
		t[i] = VACIO;

	return t;
}

/// <summary>
/// M�todo utilizado para destruir completamente la tabla hash (~TablaHash).
/// </sumary>
/// <parameter>
/// Recibe como par�metro la tabla Hash a eliminar. 
/// </parameter>
void DestruirTablaHash(TablaHash t)
{
	register int i;

	for (i = 0; i < NCASILLAS; i++) {
		if (t[i] != VACIO && t[i] != BORRADO) {
			free(t[i]);
		}
	}
	free(t);
}

/// <summary>
/// M�todo utilizado para generar los c�digos Hash (MODULARES) para cada valor.
/// </sumary>
/// <returns>
/// Devuelve un entero que indica el �ndice en la tablaHash. 
/// </returns>
/// <param>
/// Recibe como par�metro un valor char* para generar su identidad HASH. 
/// </param>
int Hash(char *cad)
{
	int valor;
	char *c;

	for (c = cad, valor = 0; *c; c++)
		valor += (int)*c;

	return (valor%NCASILLAS);
}

/// <summary>
/// M�todo utilizado para localizar un elemento char* dentro de una tabla Hash. No toma en cuenta los borrados.
/// </sumary>
/// <returns>
/// Devuelve el sitio (�ndice) donde esta "x" o donde deberia de estar. 
/// </returns>
/// <parameter>
/// Recibe como par�metros un valor char * "x" y una tabla Hash donde se desea localizar el valor. 
/// </parameter>
int Localizar(char *x, TablaHash t)
{
	int ini, i, aux;

	ini = Hash(x);

	for (i = 0; i<NCASILLAS; i++) {
		aux = (ini + i) % NCASILLAS;
		if (t[aux] == VACIO)
			return aux;
		if (!strcmp(t[aux], x))
			return aux;
	}
	return ini;
}

/// <summary>
/// M�todo utilizado para localizar un espacio disponible para un elemento cuando existe una colisi�n de HASH MODULAR.
/// No toma en cuenta los borrados.
/// </sumary>
/// <returns>
/// Devuelve el sitio donde se podr�a colocar "x". 
/// </returns>
/// <parameter>
/// Recibe como par�metros un valor char * "x" y una tabla Hash donde se desea localizar el valor. 
/// </parameter>
int Localizar1(char *x, TablaHash t)
{
	int ini, i, aux;

	ini = Hash(x);

	for (i = 0; i<NCASILLAS; i++) {
		aux = (ini + i) % NCASILLAS;
		if (t[aux] == VACIO || t[aux] == BORRADO)
			return aux;
		if (!strcmp(t[aux], x))
			return aux;
	}

	return ini;
}

/// <summary>
/// M�todo utilizado para determinar si un elemento es miembro o no de una determinada tabla HASH.
/// </sumary>
/// <returns>
/// Devuelve 1 si el valor es miembro de la Tabla HASH o 0 si no pertenece. 
/// </returns>
/// <parameter>
/// Recibe como par�metros un valor char * "cad" y una tabla Hash donde se desea localizar el valor. 
/// </parameter>
int MiembroHash(char *cad, TablaHash t)
{
	int pos = Localizar(cad, t);

	if (t[pos] == VACIO)
		return 0;
	else
		return(!strcmp(t[pos], cad));
}

/// <summary>
/// M�todo utilizado para insertar un elemento HASH dentro de una tabla indicada.
/// </sumary>
/// <parameter>
/// Recibe como par�metros un valor char * "cad", que es el elemnto deseado a ingresar en la tabla,
/// y una tabla Hash donde se desea insertar el valor. 
/// </parameter>
void InsertarHash(char *cad, TablaHash t)
{
	int pos;

	if (!cad)
		printf("Cadena inexistente.");

	if (!MiembroHash(cad, t)) {
		pos = Localizar1(cad, t);
		if (t[pos] == VACIO || t[pos] == BORRADO) {
			t[pos] = (char *)malloc((strlen(cad) + 1)*sizeof(char));
			strcpy(t[pos], cad);
		}
		else {
			printf("Tabla Llena. \n");
		}
	}
}

/// <summary>
/// M�todo utilizado para borrar un elemento HASH en la tabla indicada.
/// </sumary>
/// <parameter>
/// Recibe como par�metros un valor char * "cad", que es el elemnto deseado a eliminar de la tabla, y una tabla Hash,
/// donde se desea localizar y eliminar el valor.
/// </parameter>
void BorrarHash(char *cad, TablaHash t)
{
	int pos = Localizar(cad, t);

	if (t[pos] != VACIO && t[pos] != BORRADO) {
		if (!strcmp(t[pos], cad)) {
			free(t[pos]);
			t[pos] = BORRADO;
		}
	}
}
