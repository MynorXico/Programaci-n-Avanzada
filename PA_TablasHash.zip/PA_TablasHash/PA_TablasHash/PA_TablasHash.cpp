// PA_TablasHash.cpp: archivo de proyecto principal.

#include "stdafx.h"

using namespace System;

int main(array<System::String ^> ^args)
{
    Console::WriteLine("Falta implementaci�n:");
	NotImplementedException^ e = gcnew NotImplementedException();
	Console::WriteLine(e->Message);
	Console::ReadLine();
	return 0;
}
