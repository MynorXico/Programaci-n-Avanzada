// ConsoleApplication3.cpp : main project file.

#include "stdafx.h"
#include <string>
#include <iostream> 
#include "ABB.h"
#include "ABB.cpp";
using namespace std;
using namespace System;
ABB <int> *Arb = new ABB<int>();
int main()
{
	int valor = 0;
	bool Salir = false;
	string Op = "";

	cout << "\t\t --------------------------------------" << endl;
	cout << "\t\t | Arbol Binario de Busqueda Template |" << endl;
	cout << "\t\t --------------------------------------" << endl;
	while (!Salir)
	{
		system("cls");
		cout << "\t\t �Que Desea Realizar?" << endl;
		cout << "\t\t A. Insertar" << endl;
		//cout << "\t\t B. Eliminar" << endl;
		cout << "\t\t C. VerArbol" << endl;
		cout << "\t\t D. Recorridos" << endl;
		cout << "\t\t S. Salir" << endl;
		cin >> Op;
		if ((Op == "B")||(Op == "b"))
		{
	/*		system("cls");
			cout << "\t\t Escriba Valor a Eliminar" << endl;
			cin >> valor;
			Arb->Eliminar(valor, (Arb->root));
			system("pause");*/
		}
		else if ((Op == "A") || (Op == "a"))
		{
			system("cls");
			cout << "\t\t Escriba el Valor a Insertar" << endl;
			cin >> valor;
			Arb->Insertar(valor, (Arb->root));
			system("pause");
		}
		else if ((Op == "C") || (Op == "b"))
		{
			system("cls");
			Arb->verArbol((Arb->root),0);
			system("pause");
		}
		else if ((Op == "D") || (Op == "c"))
		{
			system("cls");
			cout << " PreOrden " << endl;
			Arb->preOrden((Arb->root));
			cout << " Orden " << endl;
			Arb->Orden((Arb->root));
			cout << " PosOrden " << endl;
			Arb->posOrden((Arb->root));
			system("pause");
		}
		else if ((Op == "S") || (Op == "d"))
		{
			Salir = true;
		}
	}
	return 0;
}
