#include "stdafx.h"
#include "ABB.h"
#include <cstdio>

template <class T> ABB<T>::ABB()
{
	root = NULL;
}
template <class T> void ABB<T>::Insertar(const T valor, nodo<T>* actual)
{
	nodo<T>* nuevo = new nodo<T>();
	nuevo->val = valor;
	if (!actual)
	{
		root = nuevo;
	}
	else
	{
		if (nuevo->val < actual->val)
		{
			if (actual->izq)
			{
				Insertar(nuevo->val , actual->izq);
			}
			else {
				actual->izq = nuevo;
			}
		}
		else if (nuevo->val > actual->val)
		{
			if (actual->der)
			{
				Insertar(nuevo->val, actual->der);
			}
			else
			{
				actual->der = nuevo;
			}
		}
	}
}
template <class T> T ABB<T>::unirArbol(nodo<T>*izq, nodo<T>* der)
{
	if (izq == NULL) return der;
	if (der == NULL) return izq;

	T centro = unirArbol(izq->der, der->izq);
	izq->der = centro;
	der->izq = izq;
	return der;
}
//template <class T> T ABB<T>::Eliminar(const T valor, nodo<T>* actual)
//{
//	if (root != NULL) {
//		if (valor < actual->val)
//		{
//			Eliminar(valor, actual->izq);
//		}
//		else if (valor > actual->val)
//		{
//			Eliminar(valor, actual->der);
//		}
//		else
//		{
//			/*T p = actual->val;
//			actual->raiz = unirArbol(actual->izq, actual->der);
//			delete p;*/
//		}
//	}
//}
template <class T> void ABB<T>::verArbol(nodo<T>* actual,const T n)
{
	if (actual != NULL) {
		for (int i = 0; i < n; i++)
			cout << "   ";

		numNodos++;
		cout << actual->val << endl;
	}
	else
	{
		if (root < actual->val)
		{
			verArbol(actual->der, n + 1);
			for (int i = 0; i < n; i++)
				cout << "   ";

			numNodos++;
			cout << actual->val;
			cout << actual->val;
		}
		else {
			verArbol(actual->izq, n + 1);
			for (int i = 0; i < n; i++)
				cout << "   ";

			numNodos++;
			cout << actual->val;
			cout << actual->val;
		}
	}
}
template <class T> void ABB<T>::preOrden(nodo<T>* actual)
{
	if (actual != NULL)
	{
		cout << actual->val << " ";
		preOrden(actual->izq);
		preOrden(actual->der);
	}
}
template <class T> void ABB<T>::Orden(nodo<T>* actual)
{
	if (actual != NULL)
	{
		preOrden(actual->izq);
		cout << actual->val << " ";
		preOrden(actual->der);
	}
}
template <class T> void ABB<T>::posOrden(nodo<T>* actual)
{
	if (actual != NULL)
	{
		preOrden(actual->izq);
		preOrden(actual->der);
		cout << actual->val << " ";
	}
}