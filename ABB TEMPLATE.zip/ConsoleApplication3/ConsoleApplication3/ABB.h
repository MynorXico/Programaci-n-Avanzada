#ifndef _ABB_H_
#define _ABB_H_

#pragma once
template <class T> struct nodo
{
	T val;
	nodo *izq;
	nodo *der;
	nodo *raiz;
};

template <class T> class ABB
{
public:
	nodo<T> *root;
	int numNodos = 0;
public:

	ABB();
	void Insertar(const T valor, nodo<T>* actual);
	T Eliminar(const T valor, nodo<T>* actual); 
	T unirArbol(nodo<T>*izq, nodo<T>*der);
	void verArbol(nodo<T>* actual, const T);
	void preOrden(nodo<T>* actual);
	void Orden(nodo<T>* actual);
	void posOrden(nodo<T>* actual);
};
#endif