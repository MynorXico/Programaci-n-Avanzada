#include "stdafx.h"
#include "Lista.h"

Lista::Lista()
{
	cabeza = nullptr;
}


Lista::~Lista()
{
}

void Lista::insertar(Nodo *nuevo)
{
	if (cabeza == NULL)
	{
		cabeza = nuevo;
		cabeza->siguiente = cabeza;
	}
	else
	{
		nuevo->siguiente = cabeza->siguiente;
		cabeza->siguiente = nuevo;
	}
}

void Lista::Mostrar(Nodo *a)
{
	do
	{
		cout << a->dato << "->";
		a = a->siguiente;
	} while (a != cabeza);
}

void Lista::MostrarRotaciones()
{
	Nodo *a = cabeza;
	Nodo *b = cabeza;
	do
	{
		do
		{
			cout << a->dato << "->";
			a = a->siguiente;
		} while (a != b);
		cout << "" << endl;
		a = a->siguiente;
		b = b->siguiente;
	} while (b != cabeza);
	
}
