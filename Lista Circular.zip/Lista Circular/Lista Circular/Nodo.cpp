#include "stdafx.h"
#include "Nodo.h"


Nodo::Nodo(int d)
{
	this->dato = d;
	this->siguiente = nullptr;
}


Nodo::~Nodo()
{
}
