#pragma once
class Nodo
{
public:
	int dato;
	Nodo *siguiente;
	Nodo(int);
	~Nodo();
};

