// Lista Circular.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Nodo.h"
#include "Lista.h"

int main()
{
	//variables
	int n�mero;
	Lista *miLista = new Lista();
	//insertar elementos a la lista
	do
	{
		system("cls");
		printf("Ingresar un n�mero a la lista, presionar 0 para salir.\n");
		cin >> n�mero;
		if (n�mero != 0)
		{
			Nodo *elemento = new Nodo(n�mero);
			miLista->insertar(elemento);
		}
	} while (n�mero != 0);
	//mostrar la lista en el orden original
	printf("\nLista en el orden original\n");
	miLista->Mostrar(miLista->cabeza);
	//Mostrar las posibles rotaciones
	printf("\nPosibles rotaciones de la lista\n");
	miLista->MostrarRotaciones();
	system("pause");
	return 0;
}

