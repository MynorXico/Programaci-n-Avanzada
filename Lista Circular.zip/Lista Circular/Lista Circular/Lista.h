#pragma once
#include "Nodo.h"
#include <iostream>
using namespace std;
class Lista
{
public:
	Nodo *cabeza;
	Lista();
	~Lista();
	void insertar(Nodo *);
	void Mostrar(Nodo *);
	void MostrarRotaciones();
};

