﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Time = System.Threading.Thread;

namespace RecursividadTorresDeHanoi
{

    public class Ttorre
    {
        private
        Button[] VecAnillos = new Button[10];
        int izquierda;
        Button Base, Poste;
        Button Anillo;
        public int sp;

        public Ttorre(int x, Form f)
        {
            f.Width = 950;
            f.Height = 350;
            x = x * 280 + 50;
            sp = 0;
            izquierda = x;
            Base = new Button();
            Base.Parent = f;
            Base.Size = new Size(230, 5);
            Base.Location = new Point(x, 280);
            Base.Show();

            //PALO
            Poste = new Button();
            Poste.Parent = f;
            Poste.Size = new Size(5, 200);
            Poste.Location = new Point(x + 115, 80);
            Poste.Show();

        }

        public Button crearanillos(int n, Form f)
        {
            Button anio = new Button();
            anio.Parent = f;
            anio.Width = 200 - (20 * sp);
            anio.Height = 10;
            anio.BringToFront();
            anio.Left = izquierda + 15 + (sp * 10);
            push(anio);
            return anio;
        }

        public void push(Button anio)
        {
            int yini, yfin;
            yfin = 270 - (sp * 10);
            yini = 50;
            while (yini < yfin)
            {
                yini = yini + 5;
                anio.Top = yini;
                Time.Sleep(3);
                anio.Refresh();
            }
            VecAnillos[sp++] = anio;


        }

        public Button pop()
        {
            int yini, yfin;
            yini = VecAnillos[sp - 1].Top;
            yfin = 50;
            while (yfin < yini)
            {
                yini = yini - 5;
                VecAnillos[sp - 1].Top = yini;
                Time.Sleep(3);
                VecAnillos[sp - 1].Refresh();
            }
            sp--;
            return VecAnillos[sp];
        }

        public Button mover(Button anio, int n)
        {
            int yini, yfin;
            yini = anio.Left;
            yfin = anio.Left + n;
            if (n > 0)
            {
                while (yfin > yini)
                {
                    yini = yini + 5;
                    anio.Left = yini;
                    Time.Sleep(3);
                    anio.Refresh();
                }

            }
            else
            {
                while (yfin < yini)
                {
                    yini = yini - 5;
                    anio.Left = yini;
                    Time.Sleep(3);
                    anio.Refresh();
                }
            }
            return anio;
        }

        public void Hanoi(Ttorre T1, Ttorre T2, Ttorre T3, int Torre)
        {
            if (Torre == 1)
            {
                Anillo = T1.pop();
                mover(Anillo, T3.izquierda - T1.izquierda);
                T3.push(Anillo);
            }
            else
            {
                Hanoi(T1, T3, T2, Torre - 1);
                Hanoi(T1, T2, T3, 1);
                Hanoi(T2, T1, T3, Torre - 1);
            }

        }
    }

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        Ttorre[] T = new Ttorre[3];

        private void button1_Click(object sender, EventArgs e)
        {
            int CantidadAnillos;
            //int valor = 0;
            for (int i = 0; i <= 2; i++)
            {
                T[i] = new Ttorre(i, this);
                this.Refresh();
            }
            try
            {
                CantidadAnillos = Convert.ToInt32(textBox1.Text);
            }
            catch
            {
                CantidadAnillos = 1;
            }
            //valor = valor + CantidadAnillos;
            if (CantidadAnillos <= 10)
            {
                for (int i = 0; i < CantidadAnillos; i++)
                {
                    T[0].crearanillos(i, this);
                }
                T[0].Hanoi(T[0], T[1], T[2], CantidadAnillos);
            }
            else
                MessageBox.Show("Limite de anillos alcanzado.");
        }
    }
}
